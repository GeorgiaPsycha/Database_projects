
-- allagi apo varchar se numeric
UPDATE public."Calendar2" SET price = replace(price, '$' , '');
UPDATE public."Calendar2" SET adjusted_price = replace(adjusted_price, '$' , '');
UPDATE public."Calendar2" SET price = replace(price, ',' , '');
UPDATE public."Calendar2" SET adjusted_price = replace(adjusted_price, ',' , '');

ALTER TABLE public."Calendar2"
ALTER COLUMN price TYPE numeric (10,3) USING price::numeric,
ALTER COLUMN adjusted_price TYPE numeric (10,3) USING adjusted_price::numeric;