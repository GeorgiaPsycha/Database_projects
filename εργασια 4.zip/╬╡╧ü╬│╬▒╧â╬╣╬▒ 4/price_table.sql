--andigrafi paidiwn
SELECT DISTINCT public."Listings2".id AS listing_id,
public."Listings2".price, 
public."Listings2".weekly_price, 
public."Listings2".monthly_price, 
public."Listings2".security_deposit, 
public."Listings2".cleaning_fee,
public."Listings2".guests_included, 
public."Listings2".extra_people, 
public."Listings2".minimum_nights, 
public."Listings2".maximum_nights,
public."Listings2".minimum_minimum_nights, 
public."Listings2".maximum_minimum_nights, 
public."Listings2".minimum_maximum_nights,
public."Listings2".maximum_maximum_nights, 
public."Listings2".minimum_nights_avg_ntm, 
public."Listings2".maximum_nights_avg_ntm
INTO "Price"
FROM public."Listings2" ;

-- sbinw ta simbola $,
UPDATE Price SET price = replace(price, '$' , '');
UPDATE Price SET price = replace(price, ',' , '');
UPDATE Price SET cleaning_fee = replace(cleaning_fee, ',' , '');
UPDATE Price SET weekly_price = replace(weekly_price, ',' , '');
UPDATE Price SET monthly_price = replace(monthly_price, '$' , '');
UPDATE Price SET security_deposit = replace(security_deposit, ',' , '');
UPDATE Price SET cleaning_fee = replace(cleaning_fee, '$' , '');
UPDATE Price SET extra_people = replace(extra_people, '$' , '');
UPDATE Price SET extra_people = replace(extra_people, ',' , '');
UPDATE Price SET minimum_nights_avg_ntm = replace(minimum_nights_avg_ntm, ',' , '');
UPDATE Price SET monthly_price = replace(monthly_price, ',' , '');
UPDATE Price SET security_deposit = replace(security_deposit, '$' , '');
UPDATE Price SET maximum_nights_avg_ntm = replace(maximum_nights_avg_ntm, ',' , '');
UPDATE Price SET weekly_price = replace(weekly_price, '$' , '');

--fk
ALTER TABLE  public."Price"
ADD FOREIGN KEY (listing_id) REFERENCES public."Listings2"(id);

-- allagi tipou apo varchar se noumeric
ALTER TABLE "Price"
ALTER COLUMN price TYPE numeric (10,3) USING price::numeric,
ALTER COLUMN weekly_price TYPE numeric(10,3) USING weekly_price::numeric,
ALTER COLUMN monthly_price TYPE numeric (10,3) USING monthly_price::numeric,
ALTER COLUMN security_deposit TYPE numeric (10,3) USING security_deposit::numeric,
ALTER COLUMN cleaning_fee TYPE numeric (10,3) USING cleaning_fee::numeric,
ALTER COLUMN extra_people TYPE numeric (10,3) USING extra_people::numeric,
ALTER COLUMN minimum_nights_avg_ntm TYPE numeric (10,3) USING minimum_nights_avg_ntm::numeric,
ALTER COLUMN maximum_nights_avg_ntm TYPE numeric  (10,3) USING maximum_nights_avg_ntm::numeric;

--drop columns
ALTER TABLE "Listings2"
DROP COLUMN price,
DROP COLUMN weekly_price,
DROP COLUMN monthly_price,
DROP COLUMN security_deposit,
DROP COLUMN cleaning_fee,
DROP COLUMN guests_included,
DROP COLUMN extra_people,
DROP COLUMN minimum_nights,
DROP COLUMN maximum_nights,
DROP COLUMN minimum_minimum_nights,
DROP COLUMN maximum_minimum_nights,
DROP COLUMN minimum_maximum_nights,
DROP COLUMN maximum_maximum_nights,
DROP COLUMN minimum_nights_avg_ntm,
DROP COLUMN maximum_nights_avg_ntm;


