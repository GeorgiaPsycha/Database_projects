--andigrafi paidiwn

SELECT distinct "Listings2".id AS listing_id,
"Listings2".street, 
"Listings2".neighbourhood, 
"Listings2".neighbourhood_cleansed, 
"Listings2".city, 
"Listings2".state,
"Listings2".zipcode, 
"Listings2".market, 
"Listings2".smart_location, 
"Listings2".country_code, 
"Listings2".country, 
"Listings2".latitude, 
"Listings2".longitude,
"Listings2".is_location_exact 
INTO "Location"
FROM "Listings2";

--FK
ALTER TABLE  public."Location"
ADD FOREIGN KEY (listing_id) REFERENCES public."Listings2"(id);

-- drop sindesi listings kai neighbourhhod
ALTER TABLE public."Listings2" DROP CONSTRAINT "Listings2_neighbourhood_cleansed_fkey"

--fk 
ALTER TABLE public."Location"
ADD FOREIGN KEY (neighbourhood_cleansed) REFERENCES public."Neighbourhoods"(neighbourhood);

--drop columns
ALTER TABLE public."Listings2"
DROP COLUMN street,
DROP COLUMN neighbourhood,
DROP COLUMN neighbourhood_cleansed,
DROP COLUMN city,
DROP COLUMN state,
DROP COLUMN zipcode,
DROP COLUMN market,
DROP COLUMN smart_location,
DROP COLUMN country_code,
DROP COLUMN country,
DROP COLUMN latitude,
DROP COLUMN longitude,
DROP COLUMN is_location_exact;
