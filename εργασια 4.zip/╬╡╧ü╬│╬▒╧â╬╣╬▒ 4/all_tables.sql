--allagi xronou apo pli8intiko se eniko 
ALTER TABLE "Listings2" RENAME TO Listing;
ALTER TABLE "Reviews2" RENAME TO Review;
ALTER TABLE "Listings_Summary2" RENAME TO Listing_Summary;
ALTER TABLE "Reviews_Summary2" RENAME TO Review_Summary;
ALTER TABLE "Neighbourhoods2" RENAME TO Neighbourhood;

-- to Calendar2 emeine etsi gia na min piraxw ton pinaka tis prWtis ergasias kai den itan se pli8intiko