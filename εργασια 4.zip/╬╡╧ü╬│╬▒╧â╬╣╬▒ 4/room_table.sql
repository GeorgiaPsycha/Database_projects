-- adigrafi paidiwn
SELECT DISTINCT "Listings2".id AS listing_id ,
        "Listings2".accommodates ,
        "Listings2".bathrooms ,
		"Listings2".bedrooms ,
		"Listings2".beds ,
		"Listings2".bed_type ,
		"Listings2".amenities  ,
		"Listings2".square_feet ,
		"Listings2".price,
		"Listings2".weekly_price,
		"Listings2".monthly_price,
		"Listings2".security_deposit
INTO "Room"
FROM "Listings2";

--fk
ALTER TABLE  public."Room"
ADD FOREIGN KEY (listing_id) REFERENCES public."Listings2"(id);

-- drop columns (ta koina me price ta kanw drop ston price) 
ALTER TABLE "Listings2"
DROP COLUMN accommodates,
DROP COLUMN bathrooms,
DROP COLUMN bedrooms,
DROP COLUMN beds,
DROP COLUMN bed_type,
DROP COLUMN amenities,
DROP COLUMN square_feet;
		