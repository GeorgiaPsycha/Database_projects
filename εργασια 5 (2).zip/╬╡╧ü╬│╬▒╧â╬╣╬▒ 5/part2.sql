
/1*the id of airbnbs which have the  exact location with the discription
Output: 9834 rows affected.*/
SELECT public."Location".listing_id,
public."Location".is_location_exact,
public."Location".street,
public.listing.availability_60,
public.listing.review_scores_value
FROM public."Location"
FULL OUTER JOIN public."listing"
  ON public."Location".Listing_id = public."listing".id
  WHERE public."Location".is_location_exact = true;


/*2.Id  of amenities that has something accurate with the TV 
Output: 4 rows affected.*/

SELECT
public."amenity".amenity_id,
public."amenity".amenity_name
FROM public."amenity"
INNER JOIN public."amenroom"
ON public."amenity".amenity_id = public."amenroom".amenity_id
WHERE public."amenity".amenity_name LIKE '%TV%'
ORDER BY public."amenity".amenity_name;


/*3. Find the cheaper to expencier rooms that have 4<= bedrooms and at least 
2 bathrooms for big families
Output: 211 rows affected.*/
SELECT
 public."Price".price,
 public."Price".minimum_nights,
 public."Room".bathrooms,
 public."Room".bedrooms
 FROM public."Price"
 FULL OUTER JOIN public."Room"
 ON public."Price".listing_id = public."Room".listing_id
  WHERE public."Room".bedrooms >= '4'
   AND public."Room".bathrooms >='2'
  ORDER BY public."Price".price ;

/*4.Top  hosts by verifications.
Output: 735 rows affected.*/
SELECT 
public."Host".id,
public."Host".name,
COUNT(public."Host".verifications)
FROM public."Host"
INNER JOIN public."listing"
ON public."Host".id = public."listing".host_id
GROUP BY public."Host".verifications, public."Host".name ,public."Host".id
HAVING COUNT(public."Host".verifications) > 2
ORDER BY COUNT(public."Host".verifications) desc
;

/*5.Finds all neighbourhoods with geometry coordinates (0,0,0,0)
Output: 45 rows affected.*/

SELECT
 public."Geolocation".geometry_coordinates_0_0_0_0,
 public."Geolocation".type,
 public."Geolocation".properties_neighbourhood,
 public."Neighbourhood".neighbourhood

 FROM public."Geolocation"
 JOIN public."Neighbourhood"
 ON public."Geolocation".properties_neighbourhood = public."Neighbourhood".neighbourhood
 GROUP BY public."Geolocation".geometry_coordinates_0_0_0_0,
 public."Geolocation".type, 
 public."Geolocation".properties_neighbourhood,
 public."Neighbourhood".neighbourhood;

