CREATE FUNCTION update_listings() RETURNS TRIGGER AS $ΕΜ$
BEGIN
      IF (TG_OP = 'INSERT') THEN
         UPDATE Host
         SET listings_count = listings_count + 1;
      ELSIF (TG_OP = 'DELETE') THEN
         UPDATE Host
         SET listings_count = listings_count - 1;
      END IF;
      RETURN NULL;
END;
$ΕΜ$ LANGUAGE  plpgsql;

CREATE TRIGGER update_listing
AFTER INSERT OR DELETE ON public.listing
   FOR EACH ROW EXECUTE PROCEDURE update_listings();


------ πηγη για την χρηση του ταγκ TG_OP ηταν η  ιστοσελιδα "https://www.postgresql.org/docs/9.1/plpgsql-trigger.html " ----------

/* το παρακατω trigger μολις εισαχθει καποιο νεο aibnb δηλ νεο id sto listing το αντιγραφει
κατευθειαν στο πινακα listing-summary */

CREATE FUNCTION ADD() RETURNS TRIGGER AS $NAME$
BEGIN 
     IF (TG_OP = 'INSERT') THEN 
        IF NEW.id NOT IN (SELECT id FROM public.listing_summary ) THEN
            INSERT INTO public.listing_summary(id)
            VALUES(NEW.id);
        END IF;
     END IF;
     RETURN NULL;
END;
$NAME$ LANGUAGE  plpgsql;


CREATE TRIGGER summary
BEFORE INSERT ON public.listing
    FOR EACH ROW EXECUTE PROCEDURE ADD();



