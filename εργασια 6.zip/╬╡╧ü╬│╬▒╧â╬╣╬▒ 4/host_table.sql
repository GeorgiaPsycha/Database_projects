-- andigrafi paidiwn
SELECT  DISTINCT "Listings2".host_id AS id,
                "Listings2".host_url AS url,
		"Listings2".host_name AS name,
		"Listings2".host_since AS since,
		"Listings2".host_location AS location,
		"Listings2".host_about AS about,
		"Listings2".host_response_time AS response_time,
		"Listings2".host_response_rate AS response_rate,
		"Listings2".host_acceptance_rate AS acceptance_rate,
		"Listings2".host_is_superhost AS is_superhost,
		"Listings2".host_thumbnail_url AS thumbnail_url,
		"Listings2".host_picture_url AS picture_url,
		"Listings2".host_neighbourhood AS neighbourhood,
		"Listings2".host_listings_count AS listings_count,
		"Listings2".host_total_listings_count AS total_listings_count,
		"Listings2".host_verifications AS verifications,
		"Listings2".host_has_profile_pic AS has_profile_pic,
		"Listings2".host_identity_verified AS identity_verified,
		"Listings2".calculated_host_listings_count AS calculated_listings_count
INTO "Host"
		
FROM "Listings2"

--PK
ALTER TABLE public."Host"
ADD PRIMARY KEY (id);

--FK
ALTER TABLE  public."Listings2"
ADD FOREIGN KEY (host_id) REFERENCES public."Host"(id);

-- DROP COLUMNS
ALTER TABLE public."Listings2"
DROP COLUMN host_url,
DROP COLUMN host_name, 
DROP COLUMN host_since, 
DROP COLUMN host_location,
DROP COLUMN host_about,
DROP COLUMN host_response_time,
DROP COLUMN host_response_rate,
DROP COLUMN host_acceptance_rate,
DROP COLUMN host_is_superhost,
DROP COLUMN host_thumbnail_url,
DROP COLUMN host_picture_url,
DROP COLUMN host_neighbourhood, 
DROP COLUMN host_listings_count,
DROP COLUMN host_total_listings_count,
DROP COLUMN host_verifications,
DROP COLUMN host_has_profile_pic,
DROP COLUMN host_identity_verified,
DROP COLUMN calculated_host_listings_count ;