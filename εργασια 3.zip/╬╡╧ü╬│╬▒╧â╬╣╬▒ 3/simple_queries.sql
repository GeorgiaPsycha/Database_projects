/*1. finds all the houses with price less than 60$ and appears only one time the
id's that have benn multiple times in the listing_id column
Output: 11541 rows affected 
*/

SELECT DISTINCT  public."Calendar".listing_id
FROM public."Calendar"
WHERE public."Calendar".price <'60' ;

/*2. Find the name and the id of the 10 first houses that have great reviews> 90 and in the same moment are cheap for less than 50 dollars at night 
Output: 10 rows affected because of limit without it 3080*/


SELECT DISTINCT public."Listings_Summary".id , 
	  public."Listings".id,
	  public."Listings_Summary".name,
	  public."Listings_Summary".price
FROM  public."Listings_Summary"
JOIN public."Listings"
ON  public."Listings".id = public."Listings_Summary".id 
   WHERE public."Listings_Summary".price < 50
   AND public."Listings".review_scores_rating > '90' 
ORDER BY public."Listings_Summary".price
   limit 10
;


/*3.Find all  the houses with good reviews in wifi which is important now with 
the pandemic and work from home . it count the number of comments that refers to 
good wifi
Output: 218 rows affected */

SELECT Count(public."Reviews".comments), public."Reviews".listing_id 
FROM public."Reviews"
WHERE comments LIKE '%good WIFI%' OR comments LIKE '%good wifi%'
Group by (public."Reviews".listing_id)
ORDER BY Count(public."Reviews".comments) Desc;


/*4. Find the id of the airbnb and the price  of it ,which is available in 31/12/2020 and had really good reviews beacuse they contain good words like great,secure,super etc 
and so the people are more likely to go to airbnbs withs good reviews and the houses are order by smaller to greater id
Output: 18633154 rows affected */


SELECT public."Calendar".listing_id,public."Calendar".price 
FROM public."Calendar"
JOIN public."Reviews"
ON  public."Reviews".listing_id = public."Calendar".listing_id
WHERE comments LIKE '%good%'OR comments LIKE '%secure%' OR comments LIKE '%great%' 
		AND  public."Calendar".date = '2020-12-31'
		AND  public."Calendar".available = true
		ORDER BY public."Calendar".listing_id;

;


/*5.Finds all the houses that locates in historical neighbourhood of acropoli perfect for tourists
and output the from cheaper to expensier
Output: 386 rows affected*/


SELECT public."Listings_Summary".name,
       public."Listings_Summary".id,
       public."Neighbourhoods".neighbourhood_group,
       public."Neighbourhoods".neighbourhood,
	   public."Listings_Summary".neighbourhood
FROM  public."Neighbourhoods"
JOIN public."Listings_Summary"
ON public."Listings_Summary".neighbourhood = public."Neighbourhoods".neighbourhood
WHERE public."Neighbourhoods".neighbourhood like 'ΑΚΡΟΠΟΛΗ'
ORDER BY public."Listings_Summary".price
;


/*6. Finds the lowest in price airbnb that apears in both callendar and 
reviews_summary in listings_id column  
Output: 1 rows affected*/

SELECT MIN(public."Calendar".price)
FROM public."Calendar" 
JOIN public."Reviews_Summary"
ON  public."Reviews_Summary".listing_id=public."Calendar".listing_id

;

/*7. Finds all house with minimun nights 1 or 2 
so is acessible to people who wonna go for little trip that either in reviews
id or listings_summary id column
Output: 100 rows affected beacuse of limit without it 375933 */

SELECT 
public."Listings_Summary".host_name,
public."Listings_Summary".neighbourhood,
public."Listings_Summary".price,
public."Listings_Summary".minimum_nights,
public."Listings_Summary".id,
public."Reviews".listing_id,
public."Reviews".comments,
public."Reviews".reviewer_name

FROM public."Listings_Summary"
FULL OUTER JOIN public."Reviews"
ON public."Listings_Summary".id = public."Reviews".listing_id
WHERE public."Listings_Summary".minimum_nights <= '2'
ORDER BY public."Listings_Summary".price 
limit 100;

/*8. Find all houses that have 2 bedrooms and 2 bathrooms so they can host 
big families or big group of friends and output them from lower to higher price
the airbnbs are either on listings.id column either on listings_summary.id
Output: 557  rows affected*/

   SELECT 
   public."Listings".id,
   public."Listings".city,
   public."Listings".availability_365,
   public."Listings".host_id,
   public."Listings".host_name,
   public."Listings".host_location,
   public."Listings".price,
   public."Listings".review_scores_cleanliness,
   public."Listings".review_scores_checkin,
   public."Listings".review_scores_communication,
   public."Listings".review_scores_location,
   public."Listings_Summary".name,
   public."Listings_Summary".id,
   
   FROM public."Listings" 
   FULL OUTER JOIN public."Listings_Summary"
   ON  public."Listings".id = public."Listings_Summary".id 
   WHERE public."Listings".bedrooms > 2
	AND public."Listings".bathrooms > '2'
   ORDER BY public."Listings_Summary".price 
   ;

/*9. Find all neighbourhoods that their names start with "Π"
and their geometry_coordinates  are starts with 37.9 or 38.0 degrees
Output: 9 rows affected */


SELECT properties_neighbourhood 
FROM public."Geolocation"
WHERE properties_neighbourhood LIKE 'Π%'
  AND (geometry_coordinates_0_0_0_1 LIKE '37.9%'
	   OR geometry_coordinates_0_0_0_1 LIKE '38.0%')



/*10.finds the  the minimum price (not null=0) of the house that can host an entire
family because the room type is Entire home/apt
Output: 1 rows affected*/

SELECT  MIN(public."Listings_Summary".price)		
FROM public."Listings_Summary"
JOIN public."Listings"
ON public."Listings_Summary".id= public."Listings".id
WHERE public."Listings_Summary".room_type='Entire home/apt'
 AND public."Listings_Summary".price >0
;


/*11.Finds the best in cleaness score houses
Output: 11499 rows affected*/

select  MAX(public."Listings".review_scores_cleanliness),
		public."Listings_Summary".name
FROM public."Listings"
JOIN public."Listings_Summary"
ON public."Listings_Summary".id= public."Listings".id
GROUP BY public."Listings_Summary".name ,  public."Listings".review_scores_cleanliness
ORDER BY public."Listings".review_scores_cleanliness
;

/*12.Finds the average price of houses in listing_summary and listing tables
Output: 1 rows affected*/

SELECT  AVG(public."Listings_Summary".price)
FROM public."Listings_Summary"
JOIN public."Listings"
ON public."Listings_Summary".id=public."Listings".id
;





